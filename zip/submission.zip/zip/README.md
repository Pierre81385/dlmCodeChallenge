# DML Coding Challenge // Zip

This is a convenience service to zip the submissions with an npm binary.

## Usage

To zip your submission, run `npm run zip`. Pretty straightforward.